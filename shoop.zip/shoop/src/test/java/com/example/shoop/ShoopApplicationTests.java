package com.example.shoop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShoopApplicationTests {

	@Test
	void contextLoads() {
	}

}
